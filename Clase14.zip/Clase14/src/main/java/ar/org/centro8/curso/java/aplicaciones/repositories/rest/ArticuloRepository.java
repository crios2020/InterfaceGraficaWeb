package ar.org.centro8.curso.java.aplicaciones.repositories.rest;

import ar.org.centro8.curso.java.aplicaciones.entities.Articulo;
import ar.org.centro8.curso.java.aplicaciones.repositories.interfaces.I_ArticuloRepository;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.util.ArrayList;
import java.util.List;

public class ArticuloRepository implements I_ArticuloRepository{
    
    private String urlServer;

    public ArticuloRepository(String urlServer) {
        this.urlServer = urlServer;
    }
    
    @Override
    public void save(Articulo articulo) {
        if(articulo==null) return;
        String url=urlServer+"/articulos/v1/save?descripcion="+articulo.getDescripcion()
                +"&tipo="+articulo.getTipo()+"&color="+articulo.getColor()
                +"&talle_num="+articulo.getTalle_num()+"&stock="+articulo.getStock()
                +"&stockMin="+articulo.getStockMin()+"&stockMax="+articulo.getStockMax()
                +"&costo="+articulo.getCosto()+"&precio="+articulo.getPrecio()
                +"&temporada="+articulo.getTemporada();
        try {
            articulo.setId(Integer.parseInt(UtilHttp.responseBody(url)));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public void remove(Articulo articulo) {
        if(articulo==null) return;
        String url=urlServer+"/articulos/v1/remove?id="+articulo.getId();
        try {
            UtilHttp.responseBody(url);
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public void update(Articulo articulo) {
        if(articulo==null) return;
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Articulo> getAll() {
        String url=urlServer+"/articulos/v1/all";
        try{
            List<Articulo> list = new Gson()
                .fromJson(UtilHttp.responseBody(url), new TypeToken<List<Articulo>>() {
                }.getType());
            return list;   
        }catch(Exception e){
            System.out.println(e);
            return new ArrayList();
        }
    }
    
}
