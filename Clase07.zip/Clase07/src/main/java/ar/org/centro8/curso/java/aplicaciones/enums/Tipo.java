package ar.org.centro8.curso.java.aplicaciones.enums;

public enum Tipo { CALZADO,ROPA }